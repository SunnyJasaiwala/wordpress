module.exports = {
  entry: {
    simpleImageSlider: ['./js/simpleImageSlider.js']
  },
  output: {
    filename: '[name].min.js'
  }
}
